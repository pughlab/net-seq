# Make sequenza files for pairing with OTB data
cat NET-001-T_2-N.gz_segments.txt NET-002-T_2-N.gz_segments.txt NET-003-T_2-N.gz_segments.txt NET-006-T_2-N.gz_segments.txt NET-007-T_2-N.gz_segments.txt NET-008-T_2-N.gz_segments.txt NET-009-T_2-N.gz_segments.txt > netseq_sequenza_segments.txt
cp netseq_sequenza_segments.txt ~/git/estimatesomaticpurity/otb_data 
